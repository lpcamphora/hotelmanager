<?php $__env->startSection('content'); ?>
<?php if($hasSurveys): ?>
    <!--Pop-up Enquete-->
    <div id="toasterEnquete" class="toast-enquete toast align-items-center" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                <h6>Enquete</h6>
                <p>Participe da enquete do nosso evento.</p>
            </div>

            <button class="btn-close-toaster ease" type="button" data-bs-dismiss="toast" aria-label="Close"><i class="fas fa-times"></i></button>
        </div>
    </div>
<?php endif; ?>

<div id="about" class="video-aula about-us section">
        <div class="container">
            <div class="row">
                <div class="section-main-video col-lg-8 align-self-center">
                    <h6 class="section-title" id="room-title">Nenhuma sala selecionada</h6>
                    <style type="text/css">
                    .video-player {
                        border-radius: 5px;
                        width: 100%;
                        margin-bottom: 16px;
                        background: #000000;
                    }                    
                    </style>
                    <div id="video-placeholder" class="video-player"></div>

                    <div class="card main-video-description" id="video-description">
                        <div class="video-title">
                            <h6 id="video-title"></h6>
                        </div> 
                        <div class="text video-date">
                            <p><i class="far fa-calendar-alt"></i><span id="video-date"></span></p>
                        </div>
                        <div class="text video-time">
                            <p><i class="far fa-clock"></i><span id="video-time"></span></p>
                        </div>
                    </div>
                </div>
                
                <!--Section Mais Vídeos -->
                <div class="main-col col-lg-4">
                    <div id="MaisVideos" class="ease section-mais-videos">
                        <h6 class="section-title">Mais vídeos</h6>
                        <div class="section-videos">
                            <div class="card card-videos">
                                <div class="card-body">
                                    <ul class="list-videos" id="videos-container"></ul>
                                </div>
                            </div>
                        </div><!--.section-videos-->
                    </div>
                
                    <!--Section Chat Ativo-->
                    <?php if($hasChat): ?>
                    <div id="ChatTempoReal" class="ease section-chat-active hide">
                        
                        <section class="section-btn-chat-mobile hide">
                            <button id="ButtonChatMobile" type="button" class="btn btn-lg btn-chat">
                                <label style="display: none; cursor: pointer;">
                                    <i class="fas fa-times"></i>
                                    <span class="chat-legenda">Fechar chat em tempo real</span>
                                </label>
                            </button>
                        </section>
                        
                        <h6 class="section-title">Chat em tempo real</h6>
                        <div class="card card-chat">
                            <ul class="list-chat" id="chat-content"></ul>
                            <div class="input-group flex-nowrap">
                                <input type="text" class="form-control" id="input-chat" aria-describedby="emailHelp" placeholder="Digite aqui..." required>
                                <div class="input-group-prepend" id="send-message" style="cursor:pointer;">
                                    <span class="input-group-text" id="addon-wrapping"><i class="fas fa-paper-plane"></i></span>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    <section class="section-btn-chat">
                        <button id="ButtonChat" type="button" class="btn btn-lg btn-chat">
                            <label class="chat-real" style="cursor: pointer;">
                                <i class="fas fa-comment-dots"></i>
                                <span class="chat-legenda">Chat em tempo real</span>
                            </label>
                            <label clas="chat-close" style="display: none; cursor: pointer;">
                                <i class="fas fa-times"></i>
                                <span class="chat-legenda">Fechar chat</span>
                            </label>
                        </button>
                    </section>
                    <?php endif; ?>
                    
                </div><!-- .main-col -->
            </div><!--.row-->
        </div><!--.container-->
    </div><!--.video-aula-->
    
    <?php if($hasSponsors): ?>
    <section class="sponsors section">
        <div class="container">
            <h6 class="section-title">Patrocinadores</h6>
            <div class="row" id="sponsors-container">
                <!--<h6 class="section-title">Patrocinadores</h6>-->
                <!--Card Patrocinadores-->
                <!--<div class="col-lg-2 col-sm-6 col-6">
                    <div class="card card-sponsors">
                        <div class="card-thumb"></div> 
                        <div class="card-sponsor-name">
                            <h6>Nome patrocinador</h6>
                        </div> 
                        <div class="card-sponsor-site">
                            <a href="#" target="_blank">mywebsite.com.br</a>
                        </div> 
                        <div class="card-sponsor-social">
                            <a class="ease" href="#" target="_blank"><button class="btn"><i class="fab fa-facebook-f"></i></button></a>
                            <a class="ease" href="#" target="_blank"><button class="btn"><i class="fab fa-instagram"></i></button></a>
                            <a class="ease" href="#" target="_blank"><button class="btn"><i class="fab fa-twitter"></i></button></a>
                            <a class="ease" href="#" target="_blank"><button class="btn"><i class="fab fa-linkedin-in"></i></button></a>
                            <a class="ease" href="#" target="_blank"><button class="btn"><i class="fab fa-youtube"></i></button></a>
                        </div>
                    </div>
                </div>-->
                <!--Card Patrocinadores-->

                <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-sm-6 col-6">
                    <div class="card card-sponsors">
                        <div class="card-thumb" style="background: url('<?php echo e(route('streaming.sponsor')); ?>?f=<?php echo e($sponsor->foto); ?>') no-repeat;"></div> 
                        <div class="card-sponsor-name">
                            <h6></h6>
                        </div> 
                        <div class="card-sponsor-site">
                            <a href="#" target="_blank"><?php echo e($sponsor->site); ?></a>
                        </div> 
                        <div class="card-sponsor-social">
                            <?php if($sponsor->facebook != ''): ?>
                            <a class="ease" href="<?php echo e($sponsor->facebook); ?>" target="_blank"><button class="btn"><i class="fab fa-facebook-f"></i></button></a>
                            <?php endif; ?>
                            <?php if($sponsor->instagram != ''): ?>
                            <a class="ease" href="<?php echo e($sponsor->instagram); ?>" target="_blank"><button class="btn"><i class="fab fa-instagram"></i></button></a>
                            <?php endif; ?>
                            <?php if($sponsor->twitter != ''): ?>
                            <a class="ease" href="<?php echo e($sponsor->twitter); ?>" target="_blank"><button class="btn"><i class="fab fa-twitter"></i></button></a>
                            <?php endif; ?>
                            <?php if($sponsor->linkedin != ''): ?>
                            <a class="ease" href="<?php echo e($sponsor->linkedin); ?>" target="_blank"><button class="btn"><i class="fab fa-linkedin-in"></i></button></a>
                            <?php endif; ?>
                            <?php if($sponsor->youtube != ''): ?>
                            <a class="ease" href="<?php echo e($sponsor->youtube); ?>" target="_blank"><button class="btn"><i class="fab fa-youtube"></i></button></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <?php endif; ?>
    <script type="text/javascript">
    window.onload = function(e) {
        $('#modalLogin').modal({'show': true});
        $('#login-btn').click();
        $('#signin').click(function(e) {
            $('#modalLogin').modal({'show': true});
        })
    };
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('streaming.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/streaming/vemaovivo/resources/views/streaming/index.blade.php ENDPATH**/ ?>