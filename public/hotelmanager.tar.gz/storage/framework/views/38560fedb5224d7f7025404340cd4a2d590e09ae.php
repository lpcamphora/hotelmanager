<?php $__env->startSection('content'); ?>



				<div class="container-fluid p-0">

					<h1 class="h3 mb-3"><strong>Quartos</strong></h1>

					<div class="row">
					<?php if(Session::has('message')): ?>
                        <p><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>

                    <div class="col-12 col-lg-12 col-xxl-9 d-flex">
							<div class="card flex-fill">
								<div class="card-header">
								<a href="<?php echo e(route('bedrooms.add')); ?>" class="btn btn-secondary" style="float:right;">Novo Quarto</a>
								</div>
								<table class="table table-hover my-0">
									<thead>
										<tr>
											<th>Nome</th>
											<th class="d-none d-xl-table-cell">Número</th>
											<th>Criado</th>
											<th>Atualizado</th>
											<th class="d-none d-md-table-cell">Ação</th>
										</tr>
									</thead>
									<tbody>
										<tr>
										<?php $__currentLoopData = $bedrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bedroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
											<td><?php echo e($bedroom->name); ?></td>
											<td class="d-none d-xl-table-cell"><?php echo e($bedroom->number); ?></td>
											<td><span class="badge bg-success"><?php echo e($bedroom->created); ?></span></td>
											<td><span class="badge bg-success"><?php echo e($bedroom->updated); ?></span></td>
											<td class="d-none d-md-table-cell">
												<a href="<?php echo e(route('bedrooms.change', $bedroom->id_bedroom)); ?>" title="Editar"><i class="align-middle" data-feather="edit"></i></a>
												<a href="javascript:;" title="Excluir" onclick="deleteUser(<?php echo e($bedroom->id_bedroom); ?>)"><i class="align-middle" data-feather="delete"></i></a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>

				</div>
				<script type="text/javascript">
				function deleteUser(id) {
					console.log(id);
					if (confirm('Deseja excluir este registro?')) {
						document.location = '/bedrooms/delete/' + id;
					}
					return;
				}
				</script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/hotelmanager/resources/views/bedrooms/index.blade.php ENDPATH**/ ?>