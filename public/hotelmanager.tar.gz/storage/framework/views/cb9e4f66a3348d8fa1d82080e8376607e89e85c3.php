<?php $__env->startSection('content'); ?>

<style type="text/css">
#add-service {
    position:absolute;
    left:35%;
    top:35%;
    width:400px;
    height:150px;
}
</style>
				<div class="container-fluid p-0">
					<h1 class="h3 mb-3"><strong>Registrar Entrada</strong></h1>
					<div class="row">
                    <div class="col-12 col-lg-12">
							<div class="card">
								<div class="card-body">
                                <?php if(Session::has('message')): ?>
                                    <p style="color:#c90000;"><?php echo e(Session::get('message')); ?></p>
                                 <?php endif; ?>
                                <form method="post" action="<?php echo e(route('index.create')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col-4 themed-grid-col">
                                        <div class="form-group">
                                            <label class="form-label">Cliente</label>
                                            <select class="form-control" name="payment_method" required>
                                                <option value=""></option>
                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
                                                <option value="<?php echo e($client->id_client); ?>"><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4 themed-grid-col">
                                        <div class="form-group">
                                            <label class="form-label">Apartamento</label>
                                            <select class="form-control" name="payment_method" required>
                                                <option value=""></option>  
                                                <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
                                                <option value="<?php echo e($apartment->id_apartment); ?>"><?php echo e($apartment->name); ?> - <?php echo e($apartment->number); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-4 themed-grid-col">
                                        <div class="form-group">
                                            <label class="form-label">Plano</label>
                                            <select class="form-control" name="payment_method" required>
                                                <option value=""></option>                                            
                                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
                                                <option value="<?php echo e($plan->id_plan); ?>"><?php echo e($plan->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                            </select>
                                        </div>
                                    </div>
                                    
                                </div>

                                <div class="row mb-3">
                                    <div class="col-4 themed-grid-col">
                                        <div class="form-group">
                                            <label class="form-label">Forma Pagamento</label>
                                            <select class="form-control" name="payment_method" required>
                                                <option value="1">Dinheiro</option>
                                                <option value="2">Cartão Crédito</option>
                                                <option value="3">Cartão Débito</option>
                                                <option value="4">PIX</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>


                                <div class="row mb-3">
                                    <div class="col-12 themed-grid-col">





                                    <div class="container-fluid p-0">

                                        <h4 class="h4 mb-3"><strong>Serviços</strong></h4>

                                        <div class="row">

                                        <div class="col-12 col-lg-12 col-xxl-9 d-flex">
                                                <div class="card flex-fill">
                                                    <div class="card-header">
                                                        <a href="javascript:;" class="btn btn-secondary" id="btn-add-service" style="float:right;">Adicionar Serviço</a>
                                                        <select class="form-control" name="payment_method" style="width:300px; float:right; margin-right:8px;" required>
                                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
                                                            <option value="<?php echo e($service->id_service); ?>"><?php echo e($service->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                                                        </select>
                                                    </div>
                                                    <table class="table table-hover my-0">
                                                        <thead>
                                                            <tr>
                                                                <th>Nome</th>
                                                                <th class="d-none d-xl-table-cell">Valor (R$)</th>
                                                                <th class="d-none d-md-table-cell">Ação</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="controls-services">
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>

                                        </div>







                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12 themed-grid-col">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-secondary" style="float:right;">Salvar</button>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12 themed-grid-col">
                                        <div class="form-group">
                                            <p style="font-size:28px; float:right;">
                                            Total: <span id="total">0,00</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                </form>

								</div>
							</div>

						</div>                    
	                </div>

				</div>

                <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

				<script type="text/javascript">
				function deleteService(id) {
					if (confirm('Deseja excluir este registro?')) {
                        $.getJSON("<?php echo e(route('index.delete.service')); ?>?s=" + ID, function(data) {
                        var json = JSON.parse(data.data);
                        streaming.video = json;
                        if (streaming.video.chat_ativo < 1) {
                            $('.section-btn-chat').css('visibility', 'hidden');
                            $('#ChatTempoReal').css('visibility', 'hidden');
                        } else {
                            $('.section-btn-chat').css('visibility', 'visible');
                            $('#ChatTempoReal').css('visibility', 'visible');
                        }
                        if (typeof callback !== "undefined") { 
                            callback();
                        }
                    });

					}
					return;
				}
                function loadServices() {
                    $.getJSON("<?php echo e(route('index.services', $id_control)); ?>?s=" + btoa(idStreaming), function(data) {
                        var json = JSON.parse(data.data);
                    });
                }
                $('#btn-add-service').click((e) => {
                    $.ajax({
                        type: 'post',
                        url: "<?php echo e(route('index.add.service', $id_control)); ?>",
                        data: JSON.stringify(this),
                        contentType: "application/json; charset=utf-8",
                        traditional: true
                    });        

                });
				</script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/hotelmanager/resources/views/index/create.blade.php ENDPATH**/ ?>