<?php $__env->startSection('content'); ?>

				<div class="container-fluid p-0">
					<h1 class="h3 mb-3"><strong>Novo Apartamento</strong></h1>
					<div class="row">
                    <div class="col-12 col-lg-12">
							<div class="card">
								<div class="card-body">
                                <?php if(Session::has('message')): ?>
                                    <p style="color:#c90000;"><?php echo e(Session::get('message')); ?></p>
                                 <?php endif; ?>
                                <form method="post" action="<?php echo e(route('apartments.add')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="col-6 themed-grid-col">
                                        <div class="form-group">
                                        <label class="form-label">Nome</label>
                                            <input type="text" class="form-control" name="name" required>
                                        </div>
                                    </div>
                                    <div class="col-6 themed-grid-col">
                                        <div class="form-group">
                                        <label class="form-label">Número</label>
                                            <input type="number" class="form-control" name="number" required>
                                        </div>
                                    </div>
                                   
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12 themed-grid-col">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-secondary" style="float:right;">Salvar</button>
                                        </div>
                                    </div>
                                </div>
                                </form>

								</div>
							</div>

						</div>                    
	                </div>

				</div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/hotelmanager/resources/views/apartments/add.blade.php ENDPATH**/ ?>