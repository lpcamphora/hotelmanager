
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title><?php echo e($event->nome ?? ''); ?></title>

    <!-- Bootstrap core CSS -->
    <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="/assets/css/all.css">
    <link rel="stylesheet" href="/assets/css/template-lab-light.css">
    <link rel="stylesheet" href="/assets/css/template-lab-dark.css">
    <link rel="stylesheet" href="/assets/css/animated.css">
    <link rel="stylesheet" href="/assets/css/owl.css">
    <!--


-->
</head>

<body id="mainBody" class="">
  <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                        <a href="<?php echo e(route('streaming')); ?>" class="logo" id="event-logo">
                            <!--<img src="/assets/images/logo.png" height="24">-->
                            <img src="<?php echo e($event->site); ?>assets/img/logo.png" height="24">
                        </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <?php if(Auth::check()): ?>
                            <!--<li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalSalas"><i class="fas fa-video"></i>Salas</a></li>-->
                            <li class="scroll-to-section"><a id="rooms"><i class="fas fa-video"></i>Salas</a></li>
                            
                            <li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalNoturno"><i class="fas fa-moon"></i>Modo Noite</a></li>
                            
                            <li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalPerfil"><i class="fas fa-user"></i>Meu Perfil</a></li>
                            
                            <!--<li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalInteracoes"><i class="fas fa-bell"></i>Interações</a></li>-->
                            <li class="scroll-to-section"><a id="surveys"><i class="fas fa-bell"></i>Interações</a></li>
                            
                            <li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalSair"><i class="fas fa-sign-out-alt"></i>Sair</a></li> 
                            <?php else: ?>
                            <li class="scroll-to-section"><a id="signin"><i class="fas fa-sign-out-alt"></i>Entrar</a></li>
                            <?php endif; ?>
                        </ul> 
                        
                        <div class="menu-mobile-exit">
                            <a data-bs-toggle="modal" data-bs-target="#modalSair"><i class="fas fa-sign-out-alt"></i></a>
                        </div>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
  <!-- ***** Header Area End ***** -->

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright">
                        <p>Vem events © 2000 - 2022 - Todos os direitos reservados.</p>
                    </div>
                </div>

            </div>
        </div>
        <?php if(Auth::check()): ?>
        <nav class="main-nav-mobile">
            <!-- ***** Menu Start ***** -->
                <ul class="nav">
                    <!--<li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalSalas"><i class="fas fa-video"></i><br><span>Salas</span></a></li>-->
                    <li class="scroll-to-section"><a id="rooms-mobile"><i class="fas fa-video"></i><br><span>Salas</span></a></li>

                    <li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalNoturno"><i class="fas fa-moon"></i><br><span>Modo Noite</span></a></li>

                    <li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalPerfil"><i class="fas fa-user"></i><br><span>Meu Perfil</span></a></li>

                    <!--<li class="scroll-to-section"><a data-bs-toggle="modal" data-bs-target="#modalInteracoes"><i class="fas fa-bell"></i><br><span>Interações</span></a></li>-->
                    <li class="scroll-to-section"><a id="surveys-mobile"><i class="fas fa-bell"></i><br><span>Interações</span></a></li>

                </ul> 
                <!-- ***** Menu End ***** -->
            </nav>
        <?php endif; ?>
    </footer>
    <!-- 
    -----------------
    MODAIS HOME 
    -----------------
    -->
    
    <!--Modal Salas-->
    <div class="modal-salas modal fade" id="modalSalas" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="container">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-video"></i>Salas disponíveis</h5>
                        <button class="ease" type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="salas-body modal-body" id="rooms-container">

                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body active">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->
                        
                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->
                        
                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->
                        
                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->
                        
                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->
                        
                        <a href="index.html" class="lista-salas-item">
                            <div class="card">
                                <div class="ease card-body">
                                    <div class="sala-header">
                                        <i class="fas fa-eye"></i><span>Agora</span>
                                    </div>
                                    <div class="sala-titulo">
                                        <i class="fas fa-eye"></i>
                                        <h6>Conecte-se experiências que transformam.</h6>
                                    </div>  
                                </div>
                            </div>
                        </a><!-- .lista-salas-item -->

                    </div>
                </div>
            </div>
        </div>
    </div><!-- .modal-salas -->
    
    
    <!--Modal Ativar Modo Noturno-->
    <div class="modal-noturno modal fade" id="modalNoturno" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="container">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-moon"></i>Ativar modo noturno</h5>
                        <button class="ease" type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <p>No modo noturno o layout tem aparência escura. Ideal para descansar a visão e economizar bateria.</p>
                        
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="SwitchCheck">
                            <label class="form-check-label check-label-noturno" for="SwitchCheck">Desligado</label>
                            <label style="display: none" class="form-check-label check-label-noturno" for="SwitchCheck">Ligado</label>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div><!-- .modal-noturno -->
    
    
    <!--Modal Perfil-->
    <div class="modal-perfil modal fade" id="modalPerfil" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="container">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-user"></i>Meu Perfil</h5>
                        <button class="ease" type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <a href=""><button type="button" class="btn" id="nav-profile"><i class="fas fa-lock"></i>Minha conta</button></a>
                        <a href=""><button type="button" class="btn" id="nav-tickets"><i class="fas fa-ticket-alt"></i>Meus ingressos</button></a>
                        <a href=""><button type="button" class="btn" id="nav-events"><i class="fas fa-star"></i>Meus eventos</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .modal-perfil -->
    
    
    <!--Modal Interações-->
    <div class="modal-interacoes modal fade" id="modalInteracoes" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="container">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-bell"></i>Interações</h5>
                        
                        <button class="ease" type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form action="">
                            <select class="form-select" aria-label="Default select example" id="surveys-items">
                            </select>
                            <select class="form-select" aria-label="Default select example" id="surveys-asks" style="top:0; left:20px; width:460px;">
                            </select>
                            <p id="survey-message">Nenhuma enquete disponível para o evento.</p>
                            <div id="survey-answers"></div>
                        </form>

                    </div><!-- .modal-body -->

                    <div class="modal-footer">
                        <button type="button" class="btn" data-bs-dismiss="modal" id="btn-send-survey" style="display:none;">Enviar</button>
                        <button type="button" class="btn" data-bs-dismiss="modal" id="btn-close-survey">Fechar</button>
                    </div>
                    
                </div>
            </div>
        </div>
    </div><!-- .modal-interacoes -->
    
    
    <!--Modal Sair-->
    <div class="modal-sair modal fade" id="modalSair" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="container">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-sign-out-alt"></i>Sair</h5>
                        <button class="ease" type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <p>Tem certeza que deseja sair da sala de transmissão?</p>
                        <div class="modal-buttons">
                            <a href="#"><button type="button" class="btn btn-cancelar">Não</button></a>
                            <a href="salas.html"><button type="button" class="btn btn-sair">Sim</button></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div><!-- .modal-sair -->


  <!-- Scripts -->
  <script src="/vendor/jquery/jquery.min.js"></script>
  <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/assets/js/owl-carousel.js"></script>
  <script src="/assets/js/animation.js"></script>
  <script src="/assets/js/imagesloaded.js"></script>
  <script src="/assets/js/custom.js"></script>
  <script src="/assets/js/inputEmoji.js"></script>
  <script src="https://www.youtube.com/iframe_api"></script>

  <script>
  // Acc
    $(document).on("click", ".naccs .menu div", function() {
      var numberIndex = $(this).index();

      if (!$(this).is("active")) {
          $(".naccs .menu div").removeClass("active");
          $(".naccs ul li").removeClass("active");

          $(this).addClass("active");
          $(".naccs ul").find("li:eq(" + numberIndex + ")").addClass("active");

          var listItemHeight = $(".naccs ul")
            .find("li:eq(" + numberIndex + ")")
            .innerHeight();
          $(".naccs ul").height(listItemHeight + "px");
        }
    });
    
    //Toaster Enquete
    $('.btn-close-toaster').click(function(){
        $('#toasterEnquete').hide('slow');
        streaming.survey = 1;
        streaming.saveData();
    });
      
    //Habilitar/desabilitar chat
    var windowWidth = $(window).innerWidth();
        if(windowWidth > 767){
        $('#ButtonChat').click(function(){
            $('#MaisVideos').toggleClass('hide');
            $('#ChatTempoReal').toggleClass('show');
            $('label').toggle(); 
        });
    }else{
        $('#ButtonChat').click(function(){
            $('#MaisVideos').toggleClass('show');
            $('#ChatTempoReal').toggleClass('show');
            $('label').toggle(); 
            $(this).hide(400);
        });
        $('#ButtonChatMobile').click(function(){
            $('#ChatTempoReal').removeClass('show');
            $('#ButtonChat').show(400);
            $('label').toggle();
        });
    }
      
    //Habilitar Modo Noturno
    $('#SwitchCheck').click(function(){
        $('#mainBody').toggleClass('dark');
        $('label.check-label-noturno').toggle();
        streaming.mode = parseInt(streaming.mode) < 1 ? 1 : 0;
        streaming.saveData();
    });

    $('.btn-cancelar').click(function(e) {
        e.preventDefault();
        $('#modalSair').modal('hide');
    });

    $('.btn-sair').click(function(e) {
        e.preventDefault();
        document.location.href = "<?php echo e(route('streaming.logout')); ?>";
    });

    var streaming = {
        user: 0,
        id_event: 0,
        id_room: 0,
        id_streaming: 0,
        id_user: 0,
        user: null,
        name: null,
        avatar: null,
        token: null,
        mode: 0,
        video: {},
        videos: [],
        room: {},
        rooms: [],
        player: null,
        done: null,
        loadData: function(callback) {
            $.getJSON("<?php echo e(route('streaming.data')); ?>", function(data) {
                var json = JSON.parse(data.data);
                streaming.user = json.user;
                streaming.id_event = json.id_event;
                streaming.id_streaming = json.id_streaming;
                streaming.id_user = json.id_user;
                streaming.user = json.user;
                streaming.name = json.name;
                streaming.avatar = json.avatar;
                streaming.token = json.token;
                streaming.mode = json.mode;
                streaming.survey = json.survey;
                callback();
            });          
        },
        saveData: function() {
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('streaming.save')); ?>",
                data: JSON.stringify(this),
                contentType: "application/json; charset=utf-8",
                traditional: true
            });        
        },
        loadVideo: function(idStreaming, callback) {
            streaming.id_streaming = idStreaming;
            streaming.saveData();
            $.getJSON("<?php echo e(route('streaming.video')); ?>?s=" + btoa(idStreaming), function(data) {
                var json = JSON.parse(data.data);
                streaming.video = json;
                if (streaming.video.chat_ativo < 1) {
                    $('.section-btn-chat').css('visibility', 'hidden');
                    $('#ChatTempoReal').css('visibility', 'hidden');
                } else {
                    $('.section-btn-chat').css('visibility', 'visible');
                    $('#ChatTempoReal').css('visibility', 'visible');
                }
                if (typeof callback !== "undefined") { 
                    callback();
                }
            });
        },
        loadVideos: function(idRoom, callback) {
            streaming.id_room = idRoom;
            $.getJSON("<?php echo e(route('streaming.videos')); ?>?r=" + btoa(idRoom), function(data) {
                var json = JSON.parse(data.data);
                streaming.videos = json;
                if (typeof callback !== "undefined") { 
                    callback();
                }
            });
        },
        loadRoom: function(idRoom, callback) {
            streaming.id_room = idRoom;
            streaming.saveData();
            $.getJSON("<?php echo e(route('streaming.room')); ?>?r=" + btoa(idRoom), function(data) {
                var json = JSON.parse(data.data);
                streaming.room = json;
                if (typeof callback !== "undefined") { 
                    callback();
                }
            });
        },
        loadRooms: function(idEvent, callback) {
            streaming.id_event = idEvent;
            $.getJSON("<?php echo e(route('streaming.rooms')); ?>?e=" + btoa(idEvent), function(data) {
                var json = JSON.parse(data.data);
                streaming.rooms = json;
                if (typeof callback !== "undefined") { 
                    callback();
                }
            });
        },
        playVideo: function() {
            if (this.player)
                this.player.destroy();
            this.player = new YT.Player('video-placeholder', {
              videoId: this.video.live_code,
              playerVars: {
                  controls: 0,
                  rel:0,
                  modestbranding: true,
                  origin: window.location.href,
              },
              events: {
                  'onReady': this.onPlayerReady,
                  'onStateChange': this.onPlayerStateChange
              }
          });
        },
        stopVideo: function() {
            this.player.stopVideo();
        },
        onPlayerReady: function(event) {
            event.target.playVideo();   
        },
        onPlayerStateChange: function(event) {
            if (event.data == YT.PlayerState.PLAYING && !this.done){
                setTimeout(this.stopVideo, 6000);
                streaming.done = true;
            }
        },
        update: function() {
            $.getJSON("<?php echo e(route('streaming.update')); ?>", function(data) {
                var json = JSON.parse(data.data);
            });
        }
    }

    var chat = {
        id_streaming: 0,
        id_user: 0,
        name: null,
        limit: 120,
        offset: 0,
        messages: [],
        receiveMessages: function(callback) {
            var limit = btoa(chat.limit);
            var offset = btoa(chat.offset);
            $.getJSON("<?php echo e(route('chat.receive')); ?>?l=" + limit + "&o=" + offset, function(data) {
                chat.messages = data.data;
                var tpl = '<li class="list-chat-item">' +
                          '          <div class="chat-avatar" style="background:url({AVATAR}) no-repeat;"></div>' +
                          '          <div class="chat-text">' + 
                          '              <h6><span class="chat-name">{NAME}: </span>{MESSAGE}</h6>' + 
                          '          </div>' + 
                          '      </li>';
                $.each(chat.messages, function(key, val) {
                    item = tpl;
                    //item = item.replace('{AVATAR}', 'https://homolog.vemaovivo.com/' + streaming.avatar);
                    item = item.replace('{AVATAR}', 'https://streaming.vemaovivo.com/chat/avatar');
                    item = item.replace('{NAME}', val.nome);
                    item = item.replace('{MESSAGE}', val.mensagem);
                    $('#chat-content').append(item);
                });
                chat.offset += parseInt(chat.messages.length);
                var content = $('#chat-content');
                content.scrollTop(content.prop("scrollHeight"));
                if (typeof callback !== 'undefined') {
                    callback();
                }
            });          
        },
        sendMessage: function() {
            var data = {
                message: $('#input-chat').val()
            };
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('chat.send')); ?>",
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                traditional: true,
                success: function(data) {
                    $('#input-chat').val('');
                }
            });        
        }
    };

    streaming.loadData(function() {
        if (streaming.mode)
            $('#SwitchCheck').click();
    });

    setInterval(chat.receiveMessages, 2000);

    setInterval(streaming.update, 3000);

    $('#input-chat').keydown(function(e) {
        if(e.keyCode == 13) {
            chat.sendMessage();
        }
    });

    $('#send-message').click(function(e) {
        chat.sendMessage();
    });

    /*$(function () {
		$('#input-chat').emoji({place: 'after'});
	});*/

    $('#rooms, #rooms-mobile').click(function(e) {
        e.preventDefault();
        $.getJSON("<?php echo e(route('streaming.rooms')); ?>", function(data) {
            var tpl = '<a href="" class="lista-salas-item" data-streaming-id="{ID}" data-room-id="{ID_ROOM}">' + 
                      '      <div class="card">' +
                      '          <div class="ease card-body {ACTIVE}">' +
                      '              <div class="sala-header">' +
                      '                  <i class="fas fa-eye"></i><span>{NOW}</span>' +
                      '              </div>' +
                      '              <div class="sala-titulo">' +
                      '                  <i class="fas fa-eye"></i>' +
                      '                  <h6>{TITLE}</h6>' +
                      '              </div>' +
                      '          </div>' +
                      '      </div>' +
                      '  </a>';
            $('#rooms-container').html('');
            var json = JSON.parse(data.data);
            if (json.length > 0) {
                $.each(json, function(key, val) {
                    var item = tpl;
                    item = item.replace('{ID}', val.id_streaming)
                            .replace('{ID_ROOM}', val.id_room)
                            .replace('{NOW}', 'Agora')
                            .replace('{TITLE}', val.title);
                    if (streaming.id_room == val.id_room) {
                        item = item.replace('{ACTIVE}', 'active');
                    } else {
                        item = item.replace('{ACTIVE}', '');
                    }
                    $('#rooms-container').append(item);
                });
                $('.lista-salas-item').unbind('click');
                $('.lista-salas-item').click(function(e) {
                    e.preventDefault();
                    var id_streaming = $(this).attr('data-streaming-id');
                    var id_room = $(this).attr('data-room-id');
                    $('#room-title').html($(this).find('h6').html());
                    streaming.loadVideos(id_room, function() {
                        var tpl = '<li class="list-videos-item" data-streaming-id="{ID}">' +
                                '     <div class="video-thumb">' +
                                '          <img src="{THUMB}" alt="Video Thumb" />' +
                                '     </div>' +
                                '     <div class="video-text">' +
                                '          <div class="video-title">' +
                                '               <h6 style="min-width:200px;">{TITLE}</h6>' +
                                '          </div>' +
                                '          <div class="video-time">' +
                                '               <p><i class="far fa-clock"></i>Há {TIME}</p>' +
                                '          </div>' +
                                '     </div>' +
                                '</li>';
                        $('#videos-container').html('');
                        $.each(streaming.videos, function(key, val) {
                            var item = tpl;
                            var thumb = 'https://img.youtube.com/vi/' + val.live_code + '/1.jpg'
                            //var thumb = "<?php echo e(route('streaming.thumb')); ?>?c=" + val.live_code;
                            item = item.replace('{ID}', val.id_streaming)
                                    .replace('{THUMB}', thumb)
                                    .replace('{TITLE}', val.nome)
                                    .replace('{TIME}', val.time);
                            $('#videos-container').append(item);
                        });
                        $('.list-videos-item').unbind('click');
                        $('.list-videos-item').click(function(e) {
                            //e.preventDefault();
                            var id_streaming = $(this).attr('data-streaming-id');
                            streaming.loadVideo(id_streaming, function() {
                                streaming.playVideo();
                            });
                        });

                        streaming.loadVideo(streaming.videos[0].id_streaming, function() {
                            $('#modalSalas').modal('hide');
                            $('#video-title').html(streaming.video.nome);
                            $('#video-date').html(streaming.video.date);
                            $('#video-time').html(streaming.video.time);
                            $('#video-description').css('visibility', 'visible');
                            streaming.playVideo();
                        });
                    });
                });
            } else {
                $('#rooms-container').append('<p>Nenhuma sala disponível</p>');
            }
            $('#modalSalas').modal('show');
        }).fail(function() {
            document.location.href = "<?php echo e(route('streaming.login')); ?>";
        });          
        
    });

    $(document).ready(function() {
        $.getJSON("<?php echo e(route('streaming.rooms')); ?>", function(data) {
            var json = JSON.parse(data.data);
            if (json.length > 0) {
                $('#room-title').html(json[0].title);
                streaming.loadVideos(json[0].id_room, function() {
                    var tpl = '<li class="list-videos-item" data-streaming-id="{ID}">' +
                                '     <div class="video-thumb">' +
                                '          <img src="{THUMB}" alt="Video Thumb" />' +
                                '     </div>' +
                                '     <div class="video-text">' +
                                '          <div class="video-title">' +
                                '               <h6 style="min-width:200px;">{TITLE}</h6>' +
                                '          </div>' +
                                '          <div class="video-time">' +
                                '               <p><i class="far fa-clock"></i>Há {TIME}</p>' +
                                '          </div>' +
                                '     </div>' +
                                '</li>';
                        $('#videos-container').html('');
                        $.each(streaming.videos, function(key, val) {
                            var item = tpl;
                            var thumb = 'https://img.youtube.com/vi/' + val.live_code + '/1.jpg'
                            //var thumb = "<?php echo e(route('streaming.thumb')); ?>?c=" + val.live_code;
                            item = item.replace('{ID}', val.id_streaming)
                                    .replace('{THUMB}', thumb)
                                    .replace('{TITLE}', val.nome)
                                    .replace('{TIME}', val.time);
                            $('#videos-container').append(item);
                        });
                        $('.list-videos-item').click(function(e) {
                            e.preventDefault();
                            var id_streaming = $(this).attr('data-streaming-id');
                            streaming.loadVideo(id_streaming, function() {
                                streaming.playVideo();
                            });
                        });

                        streaming.loadVideo(streaming.videos[0].id_streaming, function() {
                            $('#modalSalas').modal('hide');
                            $('#video-title').html(streaming.video.nome);
                            $('#video-date').html(streaming.video.date);
                            $('#video-time').html(streaming.video.time);
                            $('#video-description').css('visibility', 'visible');
                            streaming.playVideo();
                        });
                });
            } else {
                $('.video-player').css('height', $('.section-videos').height() + 'px');
                $('#ButtonChat').hide();
            }

        });
    });

    $('#surveys, #surveys-mobile').click(function(e) {
        e.preventDefault();
        $.getJSON("<?php echo e(route('streaming.surveys')); ?>", function(data) {
            var json = JSON.parse(data.data);
            var results = parseInt(json.resultados);
            var el = $('#surveys-items');
            el.html('');
            if (json.length > 0) {
                $.each(json, function(key, val) {
                    el.append($("<option />").val(val.id_enquete).text(val.nome));
                });
                el.show();
                el.unbind('change');
                el.change(function(e) {
                    $.getJSON("<?php echo e(route('streaming.asks')); ?>?s=" + btoa(el.val()), function(data) {
                        var json = JSON.parse(data.data);
                        var elm = $('#surveys-asks');
                        elm.html('');
                        $.each(json, function(key, val) {
                            elm.append($("<option />").val(val.id).text(val.pergunta));
                        });
                        elm.show();
                        elm.unbind('change');
                        elm.change(function(e) {
                            $('#survey-answers').html('');
                            $.getJSON("<?php echo e(route('streaming.ask')); ?>?a=" + btoa(elm.val()), function(data) {
                                var json = JSON.parse(data.data);
                                var tpl = '<div class="form-check form-check-inline">' +
                                    '<input class="form-check-input" type="radio" name="survey_option" id="inlineRadio1" value="{OPTION}">' +
                                    '<label class="form-check-label" for="inlineRadio1">{ANSWER} <span class="answer-percent" id="survey_option_{OPTION}"></span></label>' +
                                    '</div>';
                                for (var i = 1; i <= 10; i++) {
                                    eval('var option = json.opcao' + i + ';');
                                    if (option != '') {
                                        var item = tpl;
                                        item = item.replace('{OPTION}', i)
                                                   .replace('{OPTION}', i);
                                        item = item.replace('{ANSWER}', option);
                                        $('#survey-answers').append(item);
                                    }
                                }
                                if (json.resultados > 0) {
                                    $.getJSON("<?php echo e(route('streaming.results')); ?>?a=" + btoa(elm.val()), function(data) {
                                        var json = JSON.parse(data.data);
                                        $.each(json, function(key, val) {
                                            $('#survey_option_' + key).html(val + '%');
                                        });
                                    });
                                }
                                $.getJSON("<?php echo e(route('streaming.checkanswer')); ?>?a=" + btoa(elm.val()) + '&s=' + btoa(el.val()), function(data) {
                                    var json = JSON.parse(data.data);
                                    if (json === true) {
                                        $('#btn-send-survey').prop('disabled', true);
                                    } else {
                                        $('#btn-send-survey').prop('disabled', false);
                                    }
                                });
                            });
                        });
                        elm.change();
                    }).fail(function(xhr) {
                        if (xhr.status == 401)
                            document.location.href = "<?php echo e(route('streaming.login')); ?>";
                    });          
                });
                $('#btn-send-survey').click(function(e) {
                    e.preventDefault();
                    var data = {
                        id_survey: $('#surveys-items').val(),
                        id_ask: $('#surveys-asks').val(),
                        option: $('input[name=survey_option]:checked').val()
                    };
                    $.ajax({
                        type: 'post',
                        url: "<?php echo e(route('streaming.answer')); ?>",
                        data: JSON.stringify(data),
                        contentType: "application/json; charset=utf-8",
                        traditional: true
                    });
                    $('#btn-send-survey').prop('disabled', false);
                });
                el.change();
                $('#survey-message').hide();
                $('#btn-close-survey').hide();
                $('#btn-send-survey').show();
                $('#modalInteracoes').modal('show');
            }
        }).fail(function(xhr) {
            if (xhr.status == 401)
                document.location.href = "<?php echo e(route('streaming.login')); ?>";
        });          

    });

    $('#nav-profile').click(function(e) {
        e.preventDefault();
        var token = streaming.token;
        var url = 'https://homolog.vemaovivo.com/';
        var target = 'cadastro';
        document.location = url + 'redirect?t=' + token + '&u=' + btoa(target);
    });

    $('#nav-tickets').click(function(e) {
        e.preventDefault();
        var token = streaming.token;
        var url = 'https://homolog.vemaovivo.com/';
        var target = 'compras';
        document.location = url + 'redirect?t=' + token + '&u=' + btoa(target);
    });

    $('#nav-events').click(function(e) {
        e.preventDefault();
        var token = streaming.token;
        var url = 'https://homolog.vemaovivo.com/';
        var target = 'eventos';
        document.location = url + 'redirect?t=' + token + '&u=' + btoa(target);
    });

  </script>
</body>
</html>
<?php /**PATH /usr/local/dev/streaming/vemaovivo/resources/views/streaming/layout.blade.php ENDPATH**/ ?>