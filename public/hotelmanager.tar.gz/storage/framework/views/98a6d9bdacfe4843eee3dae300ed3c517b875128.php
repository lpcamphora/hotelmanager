<?php $__env->startSection('content'); ?>
<button type="button" data-bs-toggle="modal" data-bs-target="#modalLogin" id="login-btn"><i class="fas fa-user"></i> Entrar</button>
<div id="login" class="login-subscription section">
        <div class="container">
            <div class="row">
                <!-- Modal -->
                <div class="modal-login modal fade" id="modalLogin" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-layer-group"></i>Entrar</h5>
                                <button type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-times"></i></button>
                            </div>
                            <div class="modal-body">
                                <?php if(Session::has('message')): ?>
                                <p style="color:#c90000;"><?php echo e(Session::get('message')); ?></p>
                                <?php endif; ?>
                                <form action="<?php echo e(route('streaming.auth')); ?>" method="POST" class="needs-validation">
                                    <?php echo csrf_field(); ?>
                                    
                                    <!--Input Email-->
                                    <label for="inputEmail">Email</label><br>
                                    <div class="input-group flex-nowrap">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fas fa-envelope"></i></span>
                                        </div>
                                        <input type="email" name="email" class="form-control" id="inputEmail" aria-describedby="emailHelp" placeholder="Email da sua conta vem..." required>
                                    </div><br>
                                    
                                    <!--Input Password-->
                                    <label for="inputEmail">Senha</label><br>
                                    <div class="input-group flex-nowrap">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="addon-wrapping"><i class="fas fa-lock"></i></i></span>
                                        </div>
                                        <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Senha da sua conta vem..." required>
                                    </div><br>
                                    
                                    <input type="submit" value="Entrar">
                                </form>
                                
                            </div>
                            <div class="modal-footer">
                                <p>Não tem conta Bem? <a href="" target="_blank">Criar conta</a></p>
                                
                                <p>Esqueceu sua senha? <a href="" target="_blank">Redefinir</a></p>
                            </div>
                        </div>
                    </div>
                </div><!-- .modal-login -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .login-subscription -->
    <script type="text/javascript">
    window.onload = function(e) {
        $('#modalLogin').modal({'show': true});
        $('#login-btn').click();
        $('#signin').click(function(e) {
            $('#modalLogin').modal('show');
        });
    };
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('streaming.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/streaming/vemaovivo/resources/views/streaming/login.blade.php ENDPATH**/ ?>