<?php $__env->startSection('content'); ?>



				<div class="container-fluid p-0">

					<h1 class="h3 mb-3"><strong>Clientes</strong></h1>

					<div class="row">
					<?php if(Session::has('message')): ?>
                        <p><?php echo e(Session::get('message')); ?></p>
                    <?php endif; ?>

                    <div class="col-12 col-lg-12 col-xxl-9 d-flex">
							<div class="card flex-fill">
								<div class="card-header">
								<a href="<?php echo e(route('clients.add')); ?>" class="btn btn-secondary" style="float:right;">Novo Cliente</a>
								</div>
								<table class="table table-hover my-0">
									<thead>
										<tr>
											<th>Nome</th>
											<th class="d-none d-xl-table-cell">CPF</th>
											<th>Criado</th>
											<th>Atualizado</th>
											<th class="d-none d-md-table-cell">Ação</th>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>											
										<tr>
											<td><?php echo e($client->name); ?> <?php echo e($client->last_name); ?></td>
											<td class="d-none d-xl-table-cell"><?php echo e($client->cpf); ?></td>
											<td><span class="badge bg-success"><?php echo e($client->created); ?></span></td>
											<td><span class="badge bg-success"><?php echo e($client->updated); ?></span></td>
											<td class="d-none d-md-table-cell">
												<a href="<?php echo e(route('clients.change', $client->id_client)); ?>" title="Editar"><i class="align-middle" data-feather="edit"></i></a>
												<a href="javascript:;" title="Excluir" onclick="deleteClient(<?php echo e($client->id_client); ?>)"><i class="align-middle" data-feather="delete"></i></a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>

				</div>
				<script type="text/javascript">
				function deleteClient(id) {
					if (confirm('Deseja excluir este registro?')) {
						document.location = '/clients/delete/' + id;
					}
					return;
				}
				</script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('index.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/dev/hotelmanager/resources/views/clients/index.blade.php ENDPATH**/ ?>