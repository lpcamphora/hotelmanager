<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Clients;


class ClientsController extends Controller
{
    public function __construct(Request $request) {
    }

    public function index(Request $request) {

        $clients = Clients::getClients();

        return view('clients.index', compact('clients'));

    }    

    public function add(Request $request) {

        if ($request->isMethod('post')) {
            $result = Clients::saveClient($request->all());
            if ($result > 0 || $result === true) {
                $clients = Clients::getClients();
                return view('clients.index', compact('clients'));
            } else {
                switch ($result) {
                    case -1:
                        $message = 'Cliente não encontrado.';
                        break;
                    case -2:
                        $message = 'CPF já cadastrado.';
                        break;
                }
                Session::flash('message', $message);
            }
        }

        return view('clients.add');

    }    

    public function change(Request $request) {

        if ($request->isMethod('post')) {
            $result = Clients::saveClient($request->all());
            if ($result > 0 || $result === true) {
                $clients = Clients::getClients();
                return view('clients.index', compact('clients'));
            } else {
                switch ($result) {
                    case -1:
                        $message = 'Cliente não encontrado.';
                        break;
                    case -2:
                        $message = 'CPF já cadastrado.';
                        break;
                }
                Session::flash('message', $message);

            }
        }

        $client = Clients::find($request->id);

        return view('clients.change', compact('client'));

    }    

    public function delete(Request $request) {

        if (isset($request->id)) {
            Clients::deleteClient($request->id);
            Session::flash('message', 'Registro excluído com sucesso.');
            return redirect()->route('clients.index');
        }

    }    

}
